### 在线预览
[https://quhongqiang.com/resume/dist/](https://quhongqiang.com/resume/dist/)
## 简介
个人简历模板，fork于[https://github.com/eternityspring/eternityspring.github.io](https://github.com/eternityspring/eternityspring.github.io)
### 初始化项目
clone项目

    npm install
### 运行
    npm run serve || npm start
### 编译
    npm build
访问：http://localhost:8080/
### 制作自己的简历
找到resume.json文件，按照自己的情况修改相应的信息即可。
### 打印预览
打开上述链接，在浏览器中按
    ctrl+p
## 其他
蓝色主题版：自行修改 ./scss/style.scss 中的变量。

注意：这里用了很多css3，并不支持低版本ie。目前只自测过chrome。为了保护个人隐私，这里在展示的时候用的是网名，打印时候显示真实名字。
## License
CC BY 4.0  [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)
